See https://github.com/ssdb
